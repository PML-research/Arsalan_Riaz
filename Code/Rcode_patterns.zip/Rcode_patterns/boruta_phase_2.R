memory.size(max = FALSE)
memory.limit(size = NA)


# Libraries
library(Boruta)
library(mlbench)
library(caret)
library(randomForest)
library(readxl)

# # Data Read

LMF1 <- read.csv("Data/boruta_phase_2_data.csv", stringsAsFactors = TRUE)

# Boruta_Algorithm

set.seed(113)
boruta1 <- Boruta(Class ~ ., data = LMF1, doTrace = 2, maxRuns = 100000)

# Confirmed Features

confirmed1 <- getConfirmedFormula(boruta1)

# Boruta Details

print(boruta1)

# Print Confirmed features

confirmed1


# Data Partition
set.seed(234)
ind1 <- sample(2, nrow(LMF1), replace = T, prob = c(0.75, 0.25))

train1 <- LMF1[ind1==1,]

test1 <- LMF1[ind1==2,]


# Random Forest Model
set.seed(345)
rf1 <- randomForest(confirmed1, data = train1)


# Prediction & Confusion Matrix - Test
p1 <- predict(rf1, test1)


# Main Data 


# Sites Statistics
attStats(boruta1)

# Error rate confusion matrix

rf1

# Main accuracy prediction

confusionMatrix(p1, test1$Class)

