#read data
library(openxlsx)
library(dplyr)

Main <- read.csv("boruta_phase_3_data.csv", stringsAsFactors = T)
str(Main)

table(Main$Class)

# Data Partition

library(caret)
# 
set.seed(738)
partitionrule <- createDataPartition(Main$Class, p = .7, list = F)
trainingset <- Main[partitionrule, ]
testingset <- Main[-partitionrule, ]



# K fold cross validated Random Forest
set.seed(456)
validationrule <- trainControl(method = "repeatedcv", number = 10, repeats = 30, classProbs = T )
RF_model <- train(Class~., data = trainingset, trControl = validationrule, method = "rf", metric = 'Accuracy', importance = T)
RF_model
plot(RF_model, main = "Random Forest")

rftest <- predict(RF_model, newdata = testingset)
confusionMatrix(rftest, testingset$Class)


# K fold cross validated KNN
set.seed(789)
validationrule <- trainControl(method = "repeatedcv", number = 10, repeats = 30, classProbs = T )
KNN_model <- train(Class~., data = trainingset, trControl = validationrule, method = "knn", metric = 'Accuracy')
KNN_model
plot(KNN_model, main = "K Nearest Neighbors")
knntest <- predict(KNN_model, newdata = testingset)
confusionMatrix(knntest, testingset$Class)


# K fold cross validated SVM Linear

set.seed(987)
validationrule <- trainControl(method = "repeatedcv", number = 10, repeats = 30, classProbs = T )
SVM_model <- train(Class~., data = trainingset, trControl = validationrule, method = "svmLinear", metric = 'Accuracy', tuneLength = 10)
SVM_model
# plot(SVM_model, main = "SVM Linear")
SVMtest <- predict(SVM_model, newdata = testingset)
confusionMatrix(SVMtest, testingset$Class)


# K fold cross validated SVM Radial
set.seed(654)
validationrule <- trainControl(method = "repeatedcv", number = 10, repeats = 30, classProbs = T )
SVMR_model <- train(Class~., data = trainingset, trControl = validationrule, method = "svmRadial", metric = 'Accuracy', tuneLength = 10)
SVMR_model
plot(SVMR_model, main = "SVM Radial")
SVMRtest <- predict(SVMR_model, newdata = testingset)
confusionMatrix(SVMRtest, testingset$Class)

