memory.size(max = FALSE)
memory.limit(size = NA)


# Libraries
library(Boruta)
library(mlbench)
library(caret)
library(randomForest)
library(readxl)

# # Data Read

LMF1 <- read.csv("Data/boruta_phase_3_data.csv", stringsAsFactors = TRUE)

# Boruta_Algorithm

set.seed(113)
boruta1 <- Boruta(Class ~ ., data = LMF1, doTrace = 2, maxRuns = 50000)

# Confirmed Features

confirmed1 <- getConfirmedFormula(boruta1)

# Boruta Details

print(boruta1)

# Print Confirmed features

confirmed1


# Main Data 


# Sites Statistics
attstats_68 <- attStats(boruta1)
write.csv(attstats_68, "Data/attstats_68.csv")

plot(boruta1, las = 2, cex.axis = 0.7)
plotImpHistory(boruta1)

